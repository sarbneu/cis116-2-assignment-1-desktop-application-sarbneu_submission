CREATE DATABASE IF NOT EXISTS elevator_db;
USE elevator_db;

DROP TABLE IF EXISTS elevator_log;

CREATE TABLE elevator_log (
    log_id INT NOT NULL AUTO_INCREMENT,
    elevator_id INT NOT NULL,
    floor_no INT NOT NULL,
    event_type VARCHAR(30) NOT NULL,
    description VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (log_id)
);

SELECT * FROM elevator_log;
