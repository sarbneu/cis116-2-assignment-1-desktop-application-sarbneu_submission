using System.Collections.Concurrent;
using System.Data;
using System.Diagnostics;
using ElevatorControl.Logic;
using ElevatorControl.Persistence;

namespace ElevatorControl;

public partial class MainForm : Form, IElevatorObserver
{
    private sealed record HallButtonInfo(int Floor, Direction Direction);

    private sealed record CarButtonInfo(int ElevatorId, int Floor);

    // ---- logic
    private readonly ElevatorController _controller = new ElevatorController(2);
    private readonly System.Windows.Forms.Timer _animationTimer = new System.Windows.Forms.Timer();
    private readonly Stopwatch _clock = new Stopwatch();

    // ---- database
    private readonly AppSettings _settings;
    private readonly LogRepository _repository;
    private readonly ConcurrentQueue<ElevatorLogEntry> _pendingLogs = new ConcurrentQueue<ElevatorLogEntry>();
    private DbJob<DataTable> _loadJob;
    private DbJob<int> _saveJob;
    private bool _reloadRequested;
    private bool _dbErrorShown;

    // ---- lookup tables filled in WireUpControls (the controls themselves are declared in the Designer file)
    private readonly Dictionary<(int Floor, Direction Dir), Button> _hallButtons = new Dictionary<(int Floor, Direction Dir), Button>();
    private readonly Dictionary<(int Floor, Direction Dir), int> _hallAssignments = new Dictionary<(int Floor, Direction Dir), int>();
    private readonly Dictionary<(int ElevatorId, int Floor), Button> _carButtons = new Dictionary<(int ElevatorId, int Floor), Button>();
    private readonly Dictionary<int, Button> _emergencyButtons = new Dictionary<int, Button>();
    private readonly Dictionary<int, Label> _carStatusLabels = new Dictionary<int, Label>();

    public MainForm()
    {
        InitializeComponent(); // builds the layout (MainForm.Designer.cs)

        _settings = AppSettings.Load(out string settingsWarning);
        _repository = new LogRepository(_settings.BuildConnectionString());

        WireUpControls();
        shaftView.Controller = _controller;

        _loadJob = new DbJob<DataTable>(() => _repository.LoadLogs(), OnLogsLoaded, OnDatabaseError);
        _saveJob = new DbJob<int>(SavePendingLogs, OnLogsSaved, OnDatabaseError);

        _controller.AttachObserver(new LoggingObserver(EnqueueLog)); // observer 1 (log)
        _controller.AttachObserver(this);                            // observer 2 (buttons)
        foreach (Elevator elevator in _controller.Elevators)
        {
            elevator.ElevatorEvent += Elevator_ElevatorEvent;        // delegate (status line)
        }

        _animationTimer.Interval = 30;
        _animationTimer.Tick += AnimationTimer_Tick;

        Load += MainForm_Load;
        Shown += MainForm_Shown;
        FormClosing += MainForm_FormClosing;

        if (settingsWarning != null)
        {
            SetDbStatus(settingsWarning, true);
        }
    }

    private void WireUpControls()
    {
        // hall buttons
        RegisterHallButton(btnHallDownF1, 1, Direction.Down);
        RegisterHallButton(btnHallUpG, 0, Direction.Up);

        // car panels
        RegisterCarPanel(1, lblStatusA, btnCarAFloor1, btnCarAFloorG, btnOpenA, btnCloseA, btnEmergencyA);
        RegisterCarPanel(2, lblStatusB, btnCarBFloor1, btnCarBFloorG, btnOpenB, btnCloseB, btnEmergencyB);
    }

    private void RegisterHallButton(Button button, int floor, Direction direction)
    {
        button.Tag = new HallButtonInfo(floor, direction);
        _hallButtons[(floor, direction)] = button;
    }

    private void RegisterCarPanel(int elevatorId, Label status, Button floor1, Button floorG,
        Button open, Button close, Button emergency)
    {
        _carStatusLabels[elevatorId] = status;

        floor1.Tag = new CarButtonInfo(elevatorId, 1);
        floorG.Tag = new CarButtonInfo(elevatorId, 0);
        _carButtons[(elevatorId, 1)] = floor1;
        _carButtons[(elevatorId, 0)] = floorG;

        open.Tag = elevatorId;
        close.Tag = elevatorId;
        emergency.Tag = elevatorId;
        _emergencyButtons[elevatorId] = emergency;
    }

    private void HallCallButton_Click(object sender, EventArgs e)
    {
        var info = (HallButtonInfo)((Button)sender).Tag;

        Elevator chosen = _controller.RequestFromHall(info.Floor, info.Direction);
        if (chosen == null)
        {
            string text = $"Hall call {info.Direction} at floor {Building.FloorName(info.Floor)} rejected: no elevator available";
            SetStatus(text, true);
            EnqueueLog(new ElevatorLogEntry(0, info.Floor, ElevatorEventType.Rejected.ToString(), text));
            return;
        }

        // already at that floor
        if (chosen.HasStop(info.Floor))
        {
            _hallAssignments[(info.Floor, info.Direction)] = chosen.Id;
            SetLit(_hallButtons[(info.Floor, info.Direction)], true);
        }
    }

    private void CarFloorButton_Click(object sender, EventArgs e)
    {
        var info = (CarButtonInfo)((Button)sender).Tag;
        Elevator elevator = GetElevator(info.ElevatorId);

        if (elevator.AddStop(info.Floor, "Car panel") && elevator.HasStop(info.Floor))
        {
            SetLit(_carButtons[(info.ElevatorId, info.Floor)], true);
        }
    }

    private void OpenDoorButton_Click(object sender, EventArgs e)
    {
        GetElevator((int)((Control)sender).Tag).OpenDoors();
    }

    private void CloseDoorButton_Click(object sender, EventArgs e)
    {
        GetElevator((int)((Control)sender).Tag).CloseDoors();
    }

    private void EmergencyButton_Click(object sender, EventArgs e)
    {
        Elevator elevator = GetElevator((int)((Control)sender).Tag);
        if (elevator.IsEmergencyStopped)
        {
            elevator.Resume();
        }
        else
        {
            elevator.EmergencyStop();
        }
    }

    private void RefreshLogButton_Click(object sender, EventArgs e)
    {
        RequestReload();
    }

    private Elevator GetElevator(int id)
    {
        return _controller.Elevators[id - 1];
    }

    public void OnElevatorEvent(Elevator sender, ElevatorEventArgs e)
    {
        switch (e.Type)
        {
            case ElevatorEventType.Arrived:
                if (_carButtons.TryGetValue((sender.Id, e.Floor), out Button carButton))
                {
                    SetLit(carButton, false);
                }
                ClearHallCalls(sender.Id, e.Floor);
                break;

            case ElevatorEventType.EmergencyStop:
                UpdateEmergencyButton(sender.Id, true);
                break;

            case ElevatorEventType.Resumed:
                UpdateEmergencyButton(sender.Id, false);
                break;
        }
    }

    private void Elevator_ElevatorEvent(Elevator sender, ElevatorEventArgs e)
    {
        SetStatus(sender.Name + ": " + e.Description, e.Type == ElevatorEventType.Rejected);
    }

    private void ClearHallCalls(int elevatorId, int floor)
    {
        var served = _hallAssignments
            .Where(pair => pair.Value == elevatorId && pair.Key.Floor == floor)
            .Select(pair => pair.Key)
            .ToList();

        foreach (var key in served)
        {
            SetLit(_hallButtons[key], false);
            _hallAssignments.Remove(key);
        }
    }

    private void UpdateEmergencyButton(int elevatorId, bool active)
    {
        Button button = _emergencyButtons[elevatorId];
        button.Text = active ? "RESUME" : "EMERGENCY STOP";
        SetLit(button, active, Color.IndianRed);
    }

    private static void SetLit(Button button, bool lit, Color? color = null)
    {
        if (lit)
        {
            button.BackColor = color ?? Color.Gold;
        }
        else
        {
            button.UseVisualStyleBackColor = true;
        }
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
        _clock.Start();
        _animationTimer.Start();
    }

    private void AnimationTimer_Tick(object sender, EventArgs e)
    {
        double dt = _clock.Elapsed.TotalSeconds;
        _clock.Restart();
        if (dt > 0.2)
        {
            dt = 0.2; // limit big jumps
        }

        _controller.Tick(dt);
        shaftView.Invalidate();
        UpdateCarStatusLabels();
    }

    private void UpdateCarStatusLabels()
    {
        foreach (Elevator elevator in _controller.Elevators)
        {
            string queue = elevator.Stops.Count == 0
                ? "none"
                : string.Join(", ", elevator.Stops.Select(Building.FloorName));

            _carStatusLabels[elevator.Id].Text =
                "Floor " + Building.FloorName(elevator.CurrentFloor) + "  |  " + elevator.State.Name +
                "\r\nQueued stops: " + queue;
        }
    }

    private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
    {
        _animationTimer.Stop();
    }

    private void MainForm_Shown(object sender, EventArgs e)
    {
        RequestReload();
        EnqueueLog(new ElevatorLogEntry(0, 0, "System", "Application started"));
    }

    private void EnqueueLog(ElevatorLogEntry entry)
    {
        if (_pendingLogs.Count > 5000)
        {
            _pendingLogs.TryDequeue(out _); // drop oldest
        }

        _pendingLogs.Enqueue(entry);
        _saveJob.Run(); // ignored if already running
    }

    private int SavePendingLogs()
    {
        var batch = new List<ElevatorLogEntry>();
        while (_pendingLogs.TryDequeue(out ElevatorLogEntry entry))
        {
            batch.Add(entry);
        }

        if (batch.Count == 0)
        {
            return 0;
        }

        try
        {
            return _repository.SaveEntries(batch);
        }
        catch (Exception)
        {
            foreach (ElevatorLogEntry queued in batch)
            {
                _pendingLogs.Enqueue(queued); // try again later
            }
            throw;
        }
    }

    private void RequestReload()
    {
        if (!_loadJob.Run())
        {
            _reloadRequested = true; // reload after current load
        }
    }

    private void OnLogsLoaded(DataTable table)
    {
        logGrid.DataSource = table;
        SetDbStatus("Database: connected - showing the newest " + table.Rows.Count + " log rows", false);

        if (_reloadRequested)
        {
            _reloadRequested = false;
            _loadJob.Run();
        }
    }

    private void OnLogsSaved(int rowsWritten)
    {
        if (rowsWritten > 0)
        {
            SetDbStatus("Database: saved " + rowsWritten + " log row(s)", false);
            RequestReload();
        }

        if (!_pendingLogs.IsEmpty)
        {
            _saveJob.Run();
        }
    }

    private void OnDatabaseError(Exception ex)
    {
        _reloadRequested = false;
        SetDbStatus("Database error: " + ex.Message, true);

        if (!_dbErrorShown)
        {
            _dbErrorShown = true;
            MessageBox.Show(this,
                ex.Message + "\r\n\r\nCheck appsettings.json (next to the program) and make sure Database\\elevator_db.sql " +
                "was run in MySQL Workbench.\r\n\r\nThe elevators keep working; log entries are kept and saved once the database is reachable.",
                "Database not available",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void SetStatus(string text, bool isError)
    {
        lblStatus.Text = text;
        lblStatus.ForeColor = isError ? Color.Firebrick : SystemColors.ControlText;
    }

    private void SetDbStatus(string text, bool isError)
    {
        lblDb.Text = text;
        lblDb.ForeColor = isError ? Color.Firebrick : Color.DarkGreen;
    }
}
