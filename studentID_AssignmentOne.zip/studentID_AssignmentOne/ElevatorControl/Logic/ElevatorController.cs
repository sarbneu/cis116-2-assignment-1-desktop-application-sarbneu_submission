namespace ElevatorControl.Logic;

public class ElevatorController
{
    private readonly List<Elevator> _elevators = new List<Elevator>();

    public ElevatorController(int elevatorCount)
    {
        for (int i = 0; i < elevatorCount; i++)
        {
            char letter = (char)('A' + i);
            _elevators.Add(new Elevator(i + 1, "Elevator " + letter));
        }
    }

    public IReadOnlyList<Elevator> Elevators => _elevators;

    public void AttachObserver(IElevatorObserver observer)
    {
        foreach (Elevator elevator in _elevators)
        {
            elevator.Attach(observer);
        }
    }

    public void Tick(double dt)
    {
        foreach (Elevator elevator in _elevators)
        {
            elevator.Tick(dt);
        }
    }

    public Elevator RequestFromHall(int floor, Direction direction)
    {
        Elevator best = null;
        double bestSeconds = double.PositiveInfinity;

        foreach (Elevator elevator in _elevators)
        {
            double seconds = elevator.EstimateResponseSeconds(floor);
            if (seconds < bestSeconds) // tie goes to first elevator
            {
                best = elevator;
                bestSeconds = seconds;
            }
        }

        if (best == null)
        {
            return null;
        }

        best.AddStop(floor, $"Hall call {direction} (estimated {bestSeconds:0.0}s)");
        return best;
    }
}
