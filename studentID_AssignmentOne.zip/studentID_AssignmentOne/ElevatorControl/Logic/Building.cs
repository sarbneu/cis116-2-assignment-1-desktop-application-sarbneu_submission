namespace ElevatorControl.Logic;

public static class Building
{
    public const int FloorCount = 2;

    public const double SpeedFloorsPerSecond = 1.0;

    public const double DoorOpenSeconds = 4.0;

    public const double DoorAnimSeconds = 1.2;

    public static string FloorName(int floor)
    {
        return floor == 0 ? "G" : floor.ToString();
    }
}
