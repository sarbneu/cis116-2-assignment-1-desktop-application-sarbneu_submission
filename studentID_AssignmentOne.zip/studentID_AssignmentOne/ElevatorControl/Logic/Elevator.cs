namespace ElevatorControl.Logic;

public class Elevator
{
    internal const double Eps = 1e-6;

    private readonly List<IElevatorObserver> _observers = new List<IElevatorObserver>();
    private readonly SortedSet<int> _stops = new SortedSet<int>();
    private IElevatorState _state;

    public Elevator(int id, string name, int startFloor = 0)
    {
        Id = id;
        Name = name;
        Position = startFloor;
        _state = new IdleState();
        _state.Enter(this);
    }

    public int Id { get; }
    public string Name { get; }

    public double Position { get; internal set; }

    public int CurrentFloor => (int)Math.Round(Position);
    public Direction Direction { get; internal set; } = Direction.None;
    public bool DoorsOpen { get; internal set; }

    public double DoorOpenness { get; internal set; }

    public IElevatorState State => _state;
    public IReadOnlyCollection<int> Stops => _stops;

    public bool IsEmergencyStopped => _state is EmergencyStopState;
    public bool IsMoving => _state is MovingUpState || _state is MovingDownState;

    public event ElevatorEventHandler ElevatorEvent;

    public void Attach(IElevatorObserver observer)
    {
        if (!_observers.Contains(observer))
        {
            _observers.Add(observer);
        }
    }

    public void Detach(IElevatorObserver observer)
    {
        _observers.Remove(observer);
    }

    internal void Notify(ElevatorEventType type, string description)
    {
        var args = new ElevatorEventArgs(Id, CurrentFloor, type, description);
        foreach (IElevatorObserver observer in _observers.ToArray())
        {
            observer.OnElevatorEvent(this, args);
        }
        ElevatorEvent?.Invoke(this, args);
    }

    internal void SetState(IElevatorState newState)
    {
        _state = newState;
        _state.Enter(this);
    }

    internal void RestoreState(IElevatorState previous)
    {
        _state = previous;
    }

    public void Tick(double dt)
    {
        _state.Tick(this, dt);
        AnimateDoors(dt);
    }

    private void AnimateDoors(double dt)
    {
        if (IsEmergencyStopped)
        {
            return;
        }

        double step = dt / Building.DoorAnimSeconds;
        if (DoorsOpen)
        {
            DoorOpenness = Math.Min(1.0, DoorOpenness + step);
        }
        else
        {
            DoorOpenness = Math.Max(0.0, DoorOpenness - step);
        }
    }

    public bool AddStop(int floor, string source)
    {
        if (floor < 0 || floor >= Building.FloorCount)
        {
            return false;
        }

        string floorName = Building.FloorName(floor);

        if (IsEmergencyStopped)
        {
            Notify(ElevatorEventType.Rejected, $"{source}: floor {floorName} rejected, emergency stop is active");
            return false;
        }

        Notify(ElevatorEventType.Request, $"{source}: stop at floor {floorName}");

        bool standingAtFloor = !IsMoving && Math.Abs(Position - floor) < Eps;
        if (standingAtFloor)
        {
            if (_state is DoorsOpenState open)
            {
                open.Extend(this);
            }
            else
            {
                SetState(new DoorsOpenState());
            }
            return true;
        }

        _stops.Add(floor);
        return true;
    }

    public bool HasStop(int floor)
    {
        return _stops.Contains(floor);
    }

    public void OpenDoors()
    {
        if (IsEmergencyStopped)
        {
            Notify(ElevatorEventType.Rejected, "Open door refused: emergency stop is active");
        }
        else if (IsMoving)
        {
            Notify(ElevatorEventType.Rejected, "Open door refused: elevator is moving");
        }
        else if (_state is DoorsOpenState open)
        {
            open.Extend(this);
        }
        else
        {
            SetState(new DoorsOpenState());
        }
    }

    public void CloseDoors()
    {
        if (_state is DoorsOpenState open)
        {
            open.CloseNow(this);
        }
        else
        {
            Notify(ElevatorEventType.Rejected, "Close door ignored: doors are already closed");
        }
    }

    public void EmergencyStop()
    {
        if (!IsEmergencyStopped)
        {
            SetState(new EmergencyStopState(_state));
        }
    }

    public void Resume()
    {
        if (_state is EmergencyStopState emergency)
        {
            emergency.Resume(this);
        }
    }

    internal void RemoveStop(int floor)
    {
        _stops.Remove(floor);
    }

    internal int? NextStopAtOrAbove()
    {
        return FirstAtOrAbove(_stops, Position);
    }

    internal int? NextStopAtOrBelow()
    {
        return FirstAtOrBelow(_stops, Position);
    }

    internal void ArriveAtFloor()
    {
        Notify(ElevatorEventType.Arrived, $"Arrived at floor {Building.FloorName(CurrentFloor)}");
        SetState(new DoorsOpenState());
    }

    internal void DecideNext()
    {
        // already at this floor
        if (_stops.RemoveWhere(s => Math.Abs(s - Position) < Eps) > 0)
        {
            Position = Math.Round(Position);
            ArriveAtFloor();
            return;
        }

        bool above = FirstAtOrAbove(_stops, Position).HasValue;
        bool below = FirstAtOrBelow(_stops, Position).HasValue;

        if (Direction == Direction.Up && above)
        {
            SetState(new MovingUpState());
        }
        else if (Direction == Direction.Down && below)
        {
            SetState(new MovingDownState());
        }
        else if (above && below)
        {
            double distanceUp = FirstAtOrAbove(_stops, Position).Value - Position;
            double distanceDown = Position - FirstAtOrBelow(_stops, Position).Value;
            if (distanceUp <= distanceDown)
            {
                SetState(new MovingUpState());
            }
            else
            {
                SetState(new MovingDownState());
            }
        }
        else if (above)
        {
            SetState(new MovingUpState());
        }
        else if (below)
        {
            SetState(new MovingDownState());
        }
        else
        {
            SetState(new IdleState());
        }
    }

    public double EstimateResponseSeconds(int floor)
    {
        if (IsEmergencyStopped)
        {
            return double.PositiveInfinity;
        }

        double time = 0;
        double pos = Position;
        Direction dir = Direction;
        var pending = new SortedSet<int>(_stops) { floor };

        if (_state is DoorsOpenState open)
        {
            time += open.RemainingSeconds;
        }

        for (int guard = 0; guard < 100; guard++)
        {
            int? up = FirstAtOrAbove(pending, pos);
            int? down = FirstAtOrBelow(pending, pos);
            int? next;

            if (dir == Direction.Up && up.HasValue)
            {
                next = up;
            }
            else if (dir == Direction.Down && down.HasValue)
            {
                next = down;
            }
            else if (up.HasValue && down.HasValue)
            {
                next = (up.Value - pos <= pos - down.Value) ? up : down;
            }
            else
            {
                next = up ?? down;
            }

            if (!next.HasValue)
            {
                break;
            }

            if (next.Value > pos + Eps)
            {
                dir = Direction.Up;
            }
            else if (next.Value < pos - Eps)
            {
                dir = Direction.Down;
            }

            time += Math.Abs(next.Value - pos) / Building.SpeedFloorsPerSecond;
            pos = next.Value;
            pending.Remove(next.Value);

            if (next.Value == floor)
            {
                return time;
            }

            time += Building.DoorOpenSeconds + Building.DoorAnimSeconds; // door time
        }

        return time;
    }

    private static int? FirstAtOrAbove(SortedSet<int> stops, double position)
    {
        foreach (int s in stops)
        {
            if (s >= position - Eps)
            {
                return s;
            }
        }
        return null;
    }

    private static int? FirstAtOrBelow(SortedSet<int> stops, double position)
    {
        foreach (int s in stops.Reverse())
        {
            if (s <= position + Eps)
            {
                return s;
            }
        }
        return null;
    }
}
