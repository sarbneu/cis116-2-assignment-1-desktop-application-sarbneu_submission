namespace ElevatorControl.Logic;

public enum Direction
{
    None,
    Up,
    Down
}

public enum ElevatorEventType
{
    Request,
    MovingUp,
    MovingDown,
    Arrived,
    DoorsOpened,
    DoorsClosed,
    Idle,
    EmergencyStop,
    Resumed,
    Rejected
}

public class ElevatorEventArgs : EventArgs
{
    public ElevatorEventArgs(int elevatorId, int floor, ElevatorEventType type, string description)
    {
        ElevatorId = elevatorId;
        Floor = floor;
        Type = type;
        Description = description;
    }

    public int ElevatorId { get; }
    public int Floor { get; }
    public ElevatorEventType Type { get; }
    public string Description { get; }
}

public delegate void ElevatorEventHandler(Elevator sender, ElevatorEventArgs e);

public interface IElevatorObserver
{
    void OnElevatorEvent(Elevator sender, ElevatorEventArgs e);
}
