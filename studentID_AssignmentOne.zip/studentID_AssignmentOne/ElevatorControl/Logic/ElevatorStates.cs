namespace ElevatorControl.Logic;

public interface IElevatorState
{
    string Name { get; }

    void Enter(Elevator elevator);

    void Tick(Elevator elevator, double dt);
}

public class IdleState : IElevatorState
{
    public string Name => "Idle";

    public void Enter(Elevator elevator)
    {
        elevator.Direction = Direction.None;
        elevator.DoorsOpen = false;
        elevator.Notify(ElevatorEventType.Idle, $"Idle at floor {Building.FloorName(elevator.CurrentFloor)}");
    }

    public void Tick(Elevator elevator, double dt)
    {
        if (elevator.Stops.Count > 0)
        {
            elevator.DecideNext();
        }
    }
}

public class MovingUpState : IElevatorState
{
    public string Name => "Moving up";

    public void Enter(Elevator elevator)
    {
        elevator.Direction = Direction.Up;
        elevator.DoorsOpen = false;
        elevator.Notify(ElevatorEventType.MovingUp, $"Moving up from floor {Building.FloorName(elevator.CurrentFloor)}");
    }

    public void Tick(Elevator elevator, double dt)
    {
        if (elevator.DoorOpenness > Elevator.Eps)
        {
            return; // wait until doors are closed
        }

        int? target = elevator.NextStopAtOrAbove();
        if (!target.HasValue)
        {
            elevator.DecideNext();
            return;
        }

        elevator.Position = Math.Min(elevator.Position + Building.SpeedFloorsPerSecond * dt, target.Value);

        if (Math.Abs(elevator.Position - target.Value) < Elevator.Eps)
        {
            elevator.Position = target.Value;
            elevator.RemoveStop(target.Value);
            elevator.ArriveAtFloor();
        }
    }
}

public class MovingDownState : IElevatorState
{
    public string Name => "Moving down";

    public void Enter(Elevator elevator)
    {
        elevator.Direction = Direction.Down;
        elevator.DoorsOpen = false;
        elevator.Notify(ElevatorEventType.MovingDown, $"Moving down from floor {Building.FloorName(elevator.CurrentFloor)}");
    }

    public void Tick(Elevator elevator, double dt)
    {
        if (elevator.DoorOpenness > Elevator.Eps)
        {
            return; // wait until doors are closed
        }

        int? target = elevator.NextStopAtOrBelow();
        if (!target.HasValue)
        {
            elevator.DecideNext();
            return;
        }

        elevator.Position = Math.Max(elevator.Position - Building.SpeedFloorsPerSecond * dt, target.Value);

        if (Math.Abs(elevator.Position - target.Value) < Elevator.Eps)
        {
            elevator.Position = target.Value;
            elevator.RemoveStop(target.Value);
            elevator.ArriveAtFloor();
        }
    }
}

public class DoorsOpenState : IElevatorState
{
    private double _elapsed;

    public string Name => "Doors open";

    public double RemainingSeconds => Math.Max(0, Building.DoorOpenSeconds - _elapsed);

    public void Enter(Elevator elevator)
    {
        elevator.DoorsOpen = true;
        _elapsed = 0;
        elevator.Notify(ElevatorEventType.DoorsOpened, $"Doors opened at floor {Building.FloorName(elevator.CurrentFloor)}");
    }

    public void Tick(Elevator elevator, double dt)
    {
        _elapsed += dt;
        if (_elapsed >= Building.DoorOpenSeconds)
        {
            CloseNow(elevator);
        }
    }

    public void Extend(Elevator elevator)
    {
        _elapsed = 0;
        elevator.Notify(ElevatorEventType.DoorsOpened, $"Doors held open at floor {Building.FloorName(elevator.CurrentFloor)}");
    }

    public void CloseNow(Elevator elevator)
    {
        elevator.DoorsOpen = false;
        elevator.Notify(ElevatorEventType.DoorsClosed, $"Doors closed at floor {Building.FloorName(elevator.CurrentFloor)}");
        elevator.DecideNext();
    }
}

public class EmergencyStopState : IElevatorState
{
    private readonly IElevatorState _previous;

    public EmergencyStopState(IElevatorState previous)
    {
        _previous = previous;
    }

    public string Name => "EMERGENCY STOP";

    public void Enter(Elevator elevator)
    {
        elevator.Notify(ElevatorEventType.EmergencyStop, "Emergency stop engaged");
    }

    public void Tick(Elevator elevator, double dt)
    {
        // does nothing while stopped
    }

    public void Resume(Elevator elevator)
    {
        elevator.RestoreState(_previous);
        elevator.Notify(ElevatorEventType.Resumed, "Emergency stop released, resuming");
    }
}
