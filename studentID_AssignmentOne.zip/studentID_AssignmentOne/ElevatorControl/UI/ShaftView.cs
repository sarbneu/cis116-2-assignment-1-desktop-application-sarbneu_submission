using System.ComponentModel;
using System.Drawing.Drawing2D;
using ElevatorControl.Logic;

namespace ElevatorControl.UI;

public class ShaftView : Control
{
    private ElevatorController _controller;
    private readonly Image _doorTexture;
    private readonly Image _shaftTexture;

    public ShaftView() : this(new ElevatorController(2))
    {
    }

    public ShaftView(ElevatorController controller)
    {
        _controller = controller;
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.White;

        _doorTexture = TryLoadImage("door.png");
        _shaftTexture = TryLoadImage("shaft.png");
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ElevatorController Controller
    {
        get => _controller;
        set
        {
            _controller = value ?? _controller;
            Invalidate();
        }
    }

    private static Image TryLoadImage(string fileName)
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Images", fileName);
            if (!File.Exists(path))
            {
                return null;
            }

            using FileStream stream = File.OpenRead(path);
            using Image original = Image.FromStream(stream);
            return new Bitmap(original); // copy so file is not locked
        }
        catch (Exception ex) when (ex is IOException || ex is ArgumentException ||
                                   ex is OutOfMemoryException || ex is UnauthorizedAccessException)
        {
            return null;
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _doorTexture?.Dispose();
            _shaftTexture?.Dispose();
        }
        base.Dispose(disposing);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;

        int floors = Building.FloorCount;
        const int headerHeight = 46;
        const int footerHeight = 8;
        const int labelWidth = 34;

        IReadOnlyList<Elevator> elevators = _controller.Elevators;
        // max floor height 170
        float floorHeight = Math.Clamp((Height - headerHeight - footerHeight) / (float)floors, 30f, 170f);
        float shaftSlotWidth = (Width - labelWidth - 8) / (float)elevators.Count;

        using var boldFont = new Font("Segoe UI", 9f, FontStyle.Bold);
        using var smallFont = new Font("Segoe UI", 8.5f);
        using var linePen = new Pen(Color.Silver);
        using var textBrush = new SolidBrush(Color.FromArgb(60, 60, 60));

        // floor lines
        g.DrawLine(linePen, labelWidth - 4, headerHeight, Width - 4, headerHeight);
        for (int floor = 0; floor < floors; floor++)
        {
            float top = headerHeight + (floors - 1 - floor) * floorHeight;
            g.DrawLine(linePen, labelWidth - 4, top + floorHeight, Width - 4, top + floorHeight);
            g.DrawString(Building.FloorName(floor), boldFont, textBrush, 6, top + floorHeight / 2 - 9);
        }

        for (int i = 0; i < elevators.Count; i++)
        {
            Elevator elevator = elevators[i];
            float shaftX = labelWidth + i * shaftSlotWidth + 6;
            float shaftWidth = shaftSlotWidth - 12;

            g.DrawString(elevator.Name, boldFont, textBrush, shaftX, 4);
            g.DrawString("Floor " + Building.FloorName(elevator.CurrentFloor) + " " + Arrow(elevator.Direction),
                smallFont, textBrush, shaftX, 24);

            var shaft = new RectangleF(shaftX, headerHeight, shaftWidth, floors * floorHeight);
            DrawShaft(g, shaft);

            float carY = headerHeight + (floors - 1 - (float)elevator.Position) * floorHeight + 3;
            var car = new RectangleF(shaftX + 6, carY, shaftWidth - 12, floorHeight - 6);
            DrawCar(g, car, elevator, boldFont);
        }
    }

    private void DrawShaft(Graphics g, RectangleF shaft)
    {
        if (_shaftTexture != null)
        {
            g.DrawImage(_shaftTexture, shaft);
        }
        else
        {
            using var brush = new LinearGradientBrush(shaft, Color.FromArgb(74, 78, 86), Color.FromArgb(38, 41, 48),
                LinearGradientMode.Horizontal);
            g.FillRectangle(brush, shaft);

            // rails
            using var rail = new Pen(Color.FromArgb(120, 125, 133), 2f);
            g.DrawLine(rail, shaft.X + 3, shaft.Y, shaft.X + 3, shaft.Bottom);
            g.DrawLine(rail, shaft.Right - 3, shaft.Y, shaft.Right - 3, shaft.Bottom);
        }

        using var border = new Pen(Color.FromArgb(90, 90, 95), 2f);
        g.DrawRectangle(border, shaft.X, shaft.Y, shaft.Width, shaft.Height);
    }

    private void DrawCar(Graphics g, RectangleF car, Elevator elevator, Font font)
    {
        // frame
        using (var frame = new LinearGradientBrush(car, Color.FromArgb(214, 218, 224), Color.FromArgb(120, 126, 134),
                   LinearGradientMode.Vertical))
        {
            g.FillRectangle(frame, car);
        }
        g.DrawRectangle(Pens.DimGray, car.X, car.Y, car.Width, car.Height);

        // lamp
        const float topStrip = 11f;
        float lampSize = 6f;
        var lamp = new RectangleF(car.X + (car.Width - lampSize) / 2f, car.Y + (topStrip - lampSize) / 2f + 1f, lampSize, lampSize);
        using (var lampBrush = new SolidBrush(LampColor(elevator)))
        {
            g.FillEllipse(lampBrush, lamp);
        }
        g.DrawEllipse(Pens.DimGray, lamp);

        // door opening
        var opening = new RectangleF(car.X + 4, car.Y + topStrip, car.Width - 8, car.Height - topStrip - 4);
        if (opening.Width < 4 || opening.Height < 4)
        {
            return;
        }

        float openness = Ease((float)elevator.DoorOpenness);

        if (openness > 0.01f)
        {
            DrawInterior(g, opening);
        }

        // two doors sliding apart
        float half = opening.Width / 2f;
        float visibleWidth = half * (1f - 0.9f * openness);

        var leftVisible = new RectangleF(opening.X, opening.Y, visibleWidth, opening.Height);
        var rightVisible = new RectangleF(opening.Right - visibleWidth, opening.Y, visibleWidth, opening.Height);

        // full door rectangles
        var leftFull = new RectangleF(leftVisible.Right - half, opening.Y, half, opening.Height);
        var rightFull = new RectangleF(rightVisible.X, opening.Y, half, opening.Height);

        DrawDoorPanel(g, leftVisible, leftFull, leftPanel: true);
        DrawDoorPanel(g, rightVisible, rightFull, leftPanel: false);

        // letter on closed doors
        if (openness < 0.25f)
        {
            string letter = elevator.Name.Substring(elevator.Name.Length - 1);
            SizeF size = g.MeasureString(letter, font);
            using var letterBrush = new SolidBrush(Color.FromArgb((int)(255 * (1f - openness * 4f)), 40, 40, 45));
            g.DrawString(letter, font, letterBrush,
                opening.X + (opening.Width - size.Width) / 2f, opening.Y + (opening.Height - size.Height) / 2f);
        }
    }

    private static void DrawInterior(Graphics g, RectangleF opening)
    {
        using (var wall = new LinearGradientBrush(opening, Color.FromArgb(255, 238, 196), Color.FromArgb(188, 156, 108),
                   LinearGradientMode.Vertical))
        {
            g.FillRectangle(wall, opening);
        }

        // rail and floor
        using (var rail = new Pen(Color.FromArgb(170, 140, 95), 2f))
        {
            float y = opening.Y + opening.Height * 0.55f;
            g.DrawLine(rail, opening.X + 2, y, opening.Right - 2, y);
        }
        using (var floor = new SolidBrush(Color.FromArgb(110, 90, 62)))
        {
            g.FillRectangle(floor, opening.X, opening.Bottom - opening.Height * 0.08f, opening.Width, opening.Height * 0.08f);
        }

        // shadow at top
        using var shadow = new LinearGradientBrush(
            new RectangleF(opening.X, opening.Y, opening.Width, opening.Height * 0.25f),
            Color.FromArgb(110, 0, 0, 0), Color.FromArgb(0, 0, 0, 0), LinearGradientMode.Vertical);
        g.FillRectangle(shadow, opening.X, opening.Y, opening.Width, opening.Height * 0.25f);
    }

    private void DrawDoorPanel(Graphics g, RectangleF visible, RectangleF full, bool leftPanel)
    {
        if (visible.Width < 1f)
        {
            return;
        }

        GraphicsState state = g.Save();
        g.SetClip(visible);

        if (_doorTexture != null)
        {
            g.DrawImage(_doorTexture, full);
        }
        else
        {
            // steel colour
            using var steel = new LinearGradientBrush(full, Color.FromArgb(150, 155, 162), Color.FromArgb(150, 155, 162),
                LinearGradientMode.Horizontal);
            steel.InterpolationColors = new ColorBlend
            {
                Positions = new[] { 0f, 0.35f, 0.65f, 1f },
                Colors = new[]
                {
                    Color.FromArgb(138, 143, 150),
                    Color.FromArgb(214, 218, 223),
                    Color.FromArgb(190, 194, 200),
                    Color.FromArgb(128, 133, 140)
                }
            };
            g.FillRectangle(steel, full);
        }

        // seam line
        float edgeX = leftPanel ? visible.Right : visible.X;
        using (var seam = new Pen(Color.FromArgb(70, 70, 76), 2f))
        {
            g.DrawLine(seam, edgeX, visible.Y, edgeX, visible.Bottom);
        }

        g.Restore(state);
        g.DrawRectangle(Pens.DimGray, visible.X, visible.Y, visible.Width, visible.Height);
    }

    private static float Ease(float t)
    {
        t = Math.Clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static string Arrow(Direction direction)
    {
        switch (direction)
        {
            case Direction.Up: return "▲";
            case Direction.Down: return "▼";
            default: return "■";
        }
    }

    private static Color LampColor(Elevator elevator)
    {
        if (elevator.IsEmergencyStopped) return Color.Red;
        if (elevator.DoorsOpen) return Color.LimeGreen;
        if (elevator.IsMoving) return Color.DeepSkyBlue;
        return Color.Gold;
    }
}
