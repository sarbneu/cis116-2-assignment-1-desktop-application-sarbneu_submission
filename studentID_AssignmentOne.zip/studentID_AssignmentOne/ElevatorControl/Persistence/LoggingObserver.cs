using ElevatorControl.Logic;

namespace ElevatorControl.Persistence;

public class LoggingObserver : IElevatorObserver
{
    private readonly Action<ElevatorLogEntry> _sink;

    public LoggingObserver(Action<ElevatorLogEntry> sink)
    {
        _sink = sink;
    }

    public void OnElevatorEvent(Elevator sender, ElevatorEventArgs e)
    {
        _sink(new ElevatorLogEntry(
            e.ElevatorId,
            e.Floor,
            e.Type.ToString(),
            sender.Name + ": " + e.Description));
    }
}
