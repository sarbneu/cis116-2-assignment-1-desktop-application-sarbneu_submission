using System.Text.Json;
using MySql.Data.MySqlClient;

namespace ElevatorControl.Persistence;

public class AppSettings
{
    public string Server { get; set; } = "localhost";
    public uint Port { get; set; } = 3306;
    public string Database { get; set; } = "elevator_db";
    public string User { get; set; } = "root";
    public string Password { get; set; } = "";

    public static string SettingsPath => Path.Combine(AppContext.BaseDirectory, "appsettings.json");

    public static AppSettings Load(out string warning)
    {
        warning = null;

        try
        {
            if (!File.Exists(SettingsPath))
            {
                warning = "appsettings.json not found next to the program - using default settings.";
                return new AppSettings();
            }

            string json = File.ReadAllText(SettingsPath);
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                ReadCommentHandling = JsonCommentHandling.Skip
            };

            AppSettings settings = JsonSerializer.Deserialize<AppSettings>(json, options);
            if (settings == null)
            {
                warning = "appsettings.json is empty - using default settings.";
                return new AppSettings();
            }
            return settings;
        }
        catch (Exception ex) when (ex is IOException || ex is JsonException || ex is UnauthorizedAccessException)
        {
            warning = "Could not read appsettings.json (" + ex.Message + ") - using default settings.";
            return new AppSettings();
        }
    }

    public string BuildConnectionString()
    {
        var builder = new MySqlConnectionStringBuilder
        {
            Server = Server,
            Port = Port,
            Database = Database,
            UserID = User,
            Password = Password,
            AllowPublicKeyRetrieval = true,
            ConnectionTimeout = 5
        };
        return builder.ConnectionString;
    }
}
