using System.Data;
using MySql.Data.MySqlClient;

namespace ElevatorControl.Persistence;

public class LogRepository
{
    private const string SelectLogsSql =
        "SELECT log_id AS LogId, elevator_id AS ElevatorId, floor_no AS FloorNo, " +
        "event_type AS EventType, description AS Description, created_at AS LoggedAt " +
        "FROM elevator_log ORDER BY log_id DESC LIMIT 200";

    // no rows, only columns
    private const string SelectSchemaSql =
        "SELECT elevator_id, floor_no, event_type, description FROM elevator_log WHERE 1 = 0";

    private const string InsertSql =
        "INSERT INTO elevator_log (elevator_id, floor_no, event_type, description) " +
        "VALUES (@elevator_id, @floor_no, @event_type, @description)";

    private readonly string _connectionString;

    public LogRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public DataTable LoadLogs()
    {
        return Guard("Loading the log", () =>
        {
            using var connection = new MySqlConnection(_connectionString);
            using var adapter = new MySqlDataAdapter(SelectLogsSql, connection);

            var table = new DataTable("elevator_log");
            adapter.Fill(table); // Fill opens/closes connection
            return table;
        });
    }

    public int SaveEntries(IList<ElevatorLogEntry> entries)
    {
        return Guard("Saving log entries", () =>
        {
            using var connection = new MySqlConnection(_connectionString);
            using var adapter = new MySqlDataAdapter(SelectSchemaSql, connection);
            using var insert = new MySqlCommand(InsertSql, connection);

            insert.Parameters.Add("@elevator_id", MySqlDbType.Int32, 0, "elevator_id");
            insert.Parameters.Add("@floor_no", MySqlDbType.Int32, 0, "floor_no");
            insert.Parameters.Add("@event_type", MySqlDbType.VarChar, 30, "event_type");
            insert.Parameters.Add("@description", MySqlDbType.VarChar, 255, "description");
            insert.UpdatedRowSource = UpdateRowSource.None;
            adapter.InsertCommand = insert;

            var table = new DataTable("elevator_log");
            adapter.Fill(table);

            foreach (ElevatorLogEntry entry in entries)
            {
                table.Rows.Add(entry.ElevatorId, entry.FloorNo, entry.EventType, entry.Description);
            }

            return adapter.Update(table);
        });
    }

    private static T Guard<T>(string operation, Func<T> action)
    {
        try
        {
            return action();
        }
        catch (Exception ex) when (ex is MySqlException || ex is InvalidOperationException || ex is DBConcurrencyException)
        {
            throw new DataAccessException(operation + " failed: " + ex.Message, ex);
        }
    }
}
