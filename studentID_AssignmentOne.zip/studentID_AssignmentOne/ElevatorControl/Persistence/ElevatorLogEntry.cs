namespace ElevatorControl.Persistence;

public class ElevatorLogEntry
{
    public ElevatorLogEntry(int elevatorId, int floorNo, string eventType, string description)
    {
        ElevatorId = elevatorId;
        FloorNo = floorNo;
        EventType = Truncate(eventType, 30);
        Description = Truncate(description, 255);
    }

    public int ElevatorId { get; }
    public int FloorNo { get; }
    public string EventType { get; }
    public string Description { get; }

    private static string Truncate(string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }
        return value.Length <= maxLength ? value : value.Substring(0, maxLength);
    }
}
