using System.ComponentModel;

namespace ElevatorControl.Persistence;

public sealed class DbJob<T>
{
    private readonly BackgroundWorker _worker = new BackgroundWorker();

    public DbJob(Func<T> work, Action<T> onSuccess, Action<Exception> onError)
    {
        _worker.DoWork += (sender, e) => e.Result = work();

        _worker.RunWorkerCompleted += (sender, e) =>
        {
            if (e.Error != null)
            {
                onError(e.Error);
            }
            else
            {
                onSuccess((T)e.Result);
            }
        };
    }

    public bool IsBusy => _worker.IsBusy;

    public bool Run()
    {
        if (_worker.IsBusy)
        {
            return false;
        }
        _worker.RunWorkerAsync();
        return true;
    }
}
